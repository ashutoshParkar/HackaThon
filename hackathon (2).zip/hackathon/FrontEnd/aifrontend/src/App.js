import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [prompt, setPrompt] = useState('');
  const [conversation, setConversation] = useState([]);
  const [loading, setLoading] = useState(false);
  const [file, setFile] = useState(null);
  const [summaryType, setSummaryType] = useState('abstractive');
  const [summaryLength, setSummaryLength] = useState('medium');
  const [formatting, setFormatting] = useState('paragraph');
  const [activeTab, setActiveTab] = useState('healthcare'); // State for active tab

  const handleGenerate = () => {
    setLoading(true);
    setConversation([]);

    let url = '';
    let requestData = {};

    if (file) {
      // If a file is uploaded
      url = 'http://localhost:5000/upload';
      const formData = new FormData();
      formData.append('file', file);
      requestData = formData;
    } else if (isValidUrl(prompt)) {
      // If a URL is provided
      url = 'http://localhost:5000/summarize_url';
      requestData = { url: prompt };
    } else if (prompt) {
      // If text is provided
      url = 'http://localhost:5000/generate';
      requestData = {
        prompt,
        summaryType,
        summaryLength,
        formatting,
      };
    } else {
      console.error('Invalid input: Please provide either a text prompt, a file, or a valid URL.');
      setLoading(false);
      return;
    }

    axios.post(url, requestData)
      .then(response => {
        setConversation(prev => [...prev, { response: response.data.response }]);
        setLoading(false);
      })
      .catch(error => {
        console.error(error);
        setLoading(false);
      });
  };

  const handleFileChange = (event) => {
    const uploadedFile = event.target.files[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      setPrompt(''); // Clear text input when file is uploaded
      setConversation([]);
    }
  };

  const handleReadText = (text) => {
    if (!text) return;

    axios.post('http://localhost:5000/read', { text })
      .then(response => {
        console.log("Response from read API:", response.data);
      })
      .catch(error => {
        console.error(error);
      });
  };

  const formatResponse = (response) => {
    if (formatting === 'bulleted') {
      const sentences = response.split('. ').filter(Boolean);
      return (
        <ul>
          {sentences.map((sentence, index) => (
            <li key={index}>{sentence.trim()}</li>
          ))}
        </ul>
      );
    }
    return <p>{response}</p>;
  };

  const isValidUrl = (string) => {
    const pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
      '((([a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\\.)+[a-z]{2,}|localhost|' + // domain name
      '((\\d{1,3}\\.){3}\\d{1,3}))' + // IP address
      '(\\:\\d+)?(\\/[-a-z0-9+~%.#?&=]*)*$', 'i'); // path
    return pattern.test(string);
  };

  return (
    <div className="app">
      <header className="header">
        <h1>Text Summarizer</h1>
      </header>
      <main className="main">
        <div className="tabs-options-container">
          <div className="tabs">
            <button 
              className={`tab ${activeTab === 'generalpurpose' ? 'active' : ''}`} 
              onClick={() => setActiveTab('generalpurpose')}
            >
              General Purpose Use Case
            </button>
            <button 
              className={`tab ${activeTab === 'healthcare' ? 'active' : ''}`} 
              onClick={() => setActiveTab('healthcare')}
            >
              Healthcare Use Case
            </button>
            <button 
              className={`tab ${activeTab === 'fintech' ? 'active' : ''}`} 
              onClick={() => setActiveTab('fintech')}
            >
              Fintech Use Case
            </button>
          </div>
          <div className="options">
            <div>
              <label>Summary Type:</label>
              <button 
                className={`summary-button ${summaryType === 'abstractive' ? 'active' : ''}`} 
                onClick={() => setSummaryType('abstractive')}
              >
                Abstractive
              </button>
              <button 
                className={`summary-button ${summaryType === 'extractive' ? 'active' : ''}`} 
                onClick={() => setSummaryType('extractive')}
              >
                Extractive
              </button>
            </div>
            <div>
              <label>Summary Length:</label>
              <input 
                type="range" 
                min="1" 
                max="3" 
                value={summaryLength === 'small' ? 1 : summaryLength === 'medium' ? 2 : 3} 
                onChange={e => setSummaryLength(['small', 'medium', 'large'][e.target.value - 1])} 
              />
              <span>{summaryLength.charAt(0).toUpperCase() + summaryLength.slice(1)}</span>
            </div>
            <div>
              <label>Formatting:</label>
              <select value={formatting} onChange={e => setFormatting(e.target.value)}>
                <option value="paragraph">Paragraph</option>
                <option value="bulleted">Bullet Points</option>
              </select>
            </div>
          </div>
        </div>
        <section className="input-output-container">
          <div className="input-section">
            <label htmlFor="textInput">Enter your text or URL:</label>
            <textarea
              id="textInput"
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="Enter your prompt or URL"
              rows="10"
            />
            <label htmlFor="fileUpload">Or upload a text file:</label>
            <input
              id="fileUpload"
              type="file"
              onChange={handleFileChange}
            />
            <button onClick={handleGenerate} disabled={loading}>
              {loading ? 'Generating...' : 'Generate'}
            </button>
          </div>
          <div className="output-section">
            {conversation.map((message, index) => (
              <div key={index} className="message">
                <div
                  className="response-message"
                  style={{ cursor: 'pointer' }}
                >
                  {formatResponse(message.response)}
                </div>
                <button onClick={() => handleReadText(message.response)}>
                  Read Aloud
                </button>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
